# Web-Sitem
<<<<<<< HEAD
<<<<<<< HEAD
Bu proje, temel HTML/CSS bilgilerini kullanarak hazırladığım kendime ait bir web tasarım projesidir.
Proje ilerledikçe sayfa tasarımları ve özellikler eklenecektir.

=======
HTML,CSS,JavaScript kullanarak kendime ait web sitem.
>>>>>>> cce44f219e9c4e680229ab447ca007974bb166bc
=======
HTML,CSS,JavaScript kullanarak kendime ait web sitem.
>>>>>>> cce44f219e9c4e680229ab447ca007974bb166bc
